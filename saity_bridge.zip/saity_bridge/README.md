# Saity bridge

Installation : copier `saity_kernel.skprx` et `vitacraft.suprx` dans `ux0:tai/`, puis ajouter :
```
*KERNEL
ux0:tai/saity_kernel.skprx
*PCSE00491
ux0:tai/vitacraft.suprx
```
**CRITIQUE : le kernel doit être chargé avant le jeu.** Les fichiers sont écrits dans `ux0:data/saity/`.
